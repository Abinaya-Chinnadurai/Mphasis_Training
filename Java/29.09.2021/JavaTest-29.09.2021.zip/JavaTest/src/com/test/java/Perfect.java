package com.test.java;

public class Perfect {

	public static void main(String[] args) {
		int n=20;
        for(int i=1;i<=n;i++) {
            if(n%i == 0)
            {
            	if(i!=n)
            		System.out.println(i);
            }
        
        }
	}
}
