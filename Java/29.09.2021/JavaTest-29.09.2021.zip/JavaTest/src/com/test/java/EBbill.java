package com.test.java;

public class EBbill {
	public double unitone(double unit) {
		return unit * 1.2;
	}

	public double unittwo(double unit) {
		double newunit = unit * 1.5;
		return newunit;
	}

	public double unitthree(double unit) {
		double newunit = unit * 2;
		return newunit;
	}

	public double unitfive(double unit) {
		double newunit = unit * 3;
		return newunit;
	}

	public double unitfour(double unit) {
		double newunit = unit * 2.5;
		return newunit;
	}

	public static void main(String[] args) {
		double unit = 210;
		EBbill ob = new EBbill();
		if (unit <= 100) {
			System.out.println("the bill amount is " + ob.unitone(unit));
		}
		if (unit > 100 && unit <= 150) {
			double bill2 = ob.unittwo(unit - 100);
			System.out.println("the bill amount is " + (ob.unitone(100) + bill2));
		}
		if (unit > 150 && unit <= 200) {
			double bill3 = ob.unitthree(unit - 150);
			System.out.println("the bill amount is " + (ob.unitone(100) + ob.unittwo(50) + bill3));
		}
		if (unit > 200 && unit <= 250) {
			double bill4 = ob.unitfour(unit - 200);
			System.out.println("the bill amount is " + (ob.unitone(100) + ob.unittwo(50) + ob.unitthree(50) + bill4));
		}
		if (unit > 250) {
			double bill5 = ob.unitfive(unit - 250);
			System.out.println("the bill amount is "
					+ (ob.unitone(100) + ob.unittwo(50) + ob.unitthree(50) + ob.unitfour(50) + bill5));
		}
	}
}
