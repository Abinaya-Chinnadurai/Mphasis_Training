package com.test.java;

public class Armstrong {

	public static void main(String[] args) {

		        int number = 143, newnum, rem, result = 0;

		        newnum = number;

		        while (newnum != 0)
		        {
		        	rem = newnum % 10;
		            result += rem * rem *rem;
		            newnum /= 10;
		        }

		        if(result == number) {
		            System.out.println(number + " is Armstrong number.");}
		        else {
		            System.out.println(number + " is not Armstrong number.");
		    
		}
	}
}
