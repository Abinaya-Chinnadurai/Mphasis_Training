package com.test.java;

public class Romans {
		public String ToRoman(int num) {
			String[] ones = new String[] {"","I","II","III","IV","V","VI","VII","VIII","IX"};
			String[] tens = new String[] {"","X","XX","XXX","XL","L","LX","LXX","LXXX","XC"};
			String[] hundreds = new String[] {"","C","CC","CCC","CD","D","DC","DCC","DCCC","CM"};
			String[] thousands = new String[] {"","M","MM","MMM","MMMM"};
			
			return (thousands[num/1000]+
					hundreds[(num%1000)/100]+
					tens[(num%100)/10]+
					ones[num%10]
					);
			
		}
		
	public static void main(String[] args) {
		Romans ob = new Romans();
		int num1 = 100,num2=500;
		for(int i=num1;i<=num2;i++) {	
			System.out.println(ob.ToRoman(num1));
			num1++;
		}
		

}
}
