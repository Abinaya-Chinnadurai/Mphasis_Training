package com.test.java;

public class Twin {
 public static void main(String[] args) {
	int n1 = 1,n2=20,temp=0;
	int count=0;
	int [] arr;
	arr = new int[n2-n1];
	for(int i=n1;i<=n2;i++)
	{
		count = 0;
		for(int j=1;j<=i;j++)
		{
			if(i%j == 0)
				count++;
		}
		if(count == 2 )
		{ arr[temp]=i;temp++;}
	}
		
	for(int k =0 ; k<temp;k++) {
		if((arr[k+1]-arr[k]) == 2) {
			System.out.println(arr[k]+"," + arr[k+1]);

		}
	}
}
}
