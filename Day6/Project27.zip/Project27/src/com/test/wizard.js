QuestionNo = 0;


function loadStep5Review() {


    document.getElementById('ReviewFirstName').innerHTML = document.getElementById('fname').value;

    document.getElementById('ReviewMiddleName').innerHTML = document.getElementById('mname').value;

    document.getElementById('ReviewLastName').innerHTML = document.getElementById('lname').value;

    document.getElementById('ReviewQualification1').innerHTML = document.getElementById('Qualification1').value;

    document.getElementById('ReviewQualification2').innerHTML = document.getElementById('Qualification2').value;
   
 if (document.getElementById('Checkboxht').checked == 1) {

        document.getElementById('Reviewht').innerHTML = 'Yes';

    }

    else {

        document.getElementById('Reviewht').innerHTML = 'No';

    }

    if (document.getElementById('CheckboxJavaScript').checked == 1) {

        document.getElementById('ReviewJavaScript').innerHTML = 'Yes';

    }

    else {

        document.getElementById('ReviewJavaScript').innerHTML = 'No';

    }

    if (document.getElementById('CheckboxCSS').checked == 1) {

        document.getElementById('ReviewCSS').innerHTML = 'Yes';

    }

    else {

        document.getElementById('ReviewCSS').innerHTML = 'No';

    }

    if (document.getElementById('CheckboxPM').checked == 1) {

        document.getElementById('ReviewPM').innerHTML = 'Yes';

    }

    else {

        document.getElementById('ReviewPM').innerHTML = 'No';

    }
    if (document.getElementById('Checkboxjava').checked == 1) {

        document.getElementById('Reviewjava').innerHTML = 'Yes';

    }

    else {

        document.getElementById('Reviewjava').innerHTML = 'No';

    }
    if (document.getElementById('CheckboxTD').checked == 1) {

        document.getElementById('ReviewTD').innerHTML = 'Yes';

    }

    else {

        document.getElementById('ReviewTD').innerHTML = 'No';

    }
if (document.getElementById('Checkboxdb').checked == 1) {

        document.getElementById('Reviewdb').innerHTML = 'Yes';

    }

    else {

        document.getElementById('Reviewdb').innerHTML = 'No';

    }
if (document.getElementById('Checkboxsq').checked == 1) {

        document.getElementById('Reviewsq').innerHTML = 'Yes';

    }

    else {

        document.getElementById('Reviewsq').innerHTML = 'No';

    }


}

function load()
{
    var BG = Math.floor(Math.random() * 5);
    if (BG == 0) { document.body.background = "exambg1.jpg"; }
    else if (BG == 1) { document.body.background = "exambg2.jpg"; }
    else if (BG == 2) { document.body.background = "exambg3.jpg"; }
    else if (BG == 3) { document.body.background = "exambg4.jpg"; }
    else { document.body.background = "exambg5.jpg"; }
	LoadQuestion();
}

function LoadQuestion()
{
    var x = document.getElementById("previous");
    document.getElementById("submit").style.display = "none";
    document.getElementById("next").style.display = "inline";
    if (QuestionNo == 0) {
        x.style.display = "none";
    } else {
        x.style.display = "inline";
    }

    if (QuestionNo == 2) {
        document.getElementById("submit").style.display = "inline";
        document.getElementById("next").style.display = "none";
    }
    if (QuestionNo == 3) {
        document.getElementById("submit").style.display = "inline";
        document.getElementById("next").style.display = "none";
    }
    document.getElementById('headertable').style.backgroundColor = 'black';
	Answer = 3;
}

function PreviousQuestion() {
    QuestionNo--;
    load();
    if (document.getElementById('previous').name == 'Step1') {
        document.getElementById('next').name = 'Step2';
        document.getElementById('previous').name = 'Step0';
        document.getElementById('Step1').style.display = 'inline';
        document.getElementById('Step2').style.display = 'none';
        document.getElementById('HeaderTableStep2').style.backgroundColor = '#2bc9cf';
        document.getElementById('HeaderTableStep3').style.backgroundColor = '#2bcf51';
        document.getElementById('HeaderTableStep1').style.backgroundColor = '#2bcf51';
    } else if (document.getElementById('previous').name == 'Step2') {
        document.getElementById('next').name = 'Step3';
        document.getElementById('previous').name = 'Step1';
        document.getElementById('Step2').style.display = 'inline';
        document.getElementById('Step3').style.display = 'none';
        document.getElementById('HeaderTableStep2').style.backgroundColor = '#2bc9cf';
        document.getElementById('HeaderTableStep3').style.backgroundColor = '#2bcf51';
        document.getElementById('HeaderTableStep1').style.backgroundColor = '#2bcf51';
    } else if (document.getElementById('previous').name == 'Step3') {
        document.getElementById('previous').name = 'Step2';
        document.getElementById('Step3').style.display = 'inline';
        document.getElementById('Step4').style.display = 'none';
        document.getElementById('HeaderTableStep4').style.backgroundColor = '#2bcf51';
        document.getElementById('HeaderTableStep3').style.backgroundColor = '#2bc9cf';
        document.getElementById('HeaderTableStep1').style.backgroundColor = '#2bcf51';

    }
}

function NextQuestion()
{
    if (document.getElementById('next').name == "Step2") {
	var fname = document.getElementById("fname").value;
        if (fname == '') {
           alert("Enter your Firstname...") ;
           return;
        } else {
            document.getElementById("errFirstName").innerHTML = "";
        }
        var lname = document.getElementById("lname").value;
        if (lname == '') {
            alert("Enter your Lastname...") 
            return;
        } else {
            document.getElementById("errLastName").innerHTML = "";
        }
        QuestionNo++;
        load();
        document.getElementById('next').name = 'Step3';
        document.getElementById('previous').name = 'Step1';
        document.getElementById('Step1').style.display = 'none';
        document.getElementById('Step2').style.display = 'inline';
        document.getElementById('HeaderTableStep2').style.backgroundColor = '#2bc9cf';
        document.getElementById('HeaderTableStep1').style.backgroundColor = '#2bcf51';
    } else if (document.getElementById('next').name == "Step3") {
        QuestionNo++;
        load();
        document.getElementById('next').name = 'Step4';
        document.getElementById('previous').name = 'Step2';
        document.getElementById('Step2').style.display = 'none';
        document.getElementById('Step3').style.display = 'inline';
        document.getElementById('HeaderTableStep3').style.backgroundColor = '#2bc9cf';
        document.getElementById('HeaderTableStep2').style.backgroundColor = '#2bcf51';
    }
    else if (document.getElementById('next').name == "Step4") {
        QuestionNo++;
        load();

        document.getElementById('previous').name = 'Step3';
        document.getElementById('Step3').style.display = 'none';
        document.getElementById('Step4').style.display = 'none';
        document.getElementById('HeaderTableStep2').style.backgroundColor = '#2bc9cf';
        document.getElementById('HeaderTableStep1').style.backgroundColor = '#2bcf51';
    }
}

function ShowSummary() {
    load();
    QuestionNo++;
    document.getElementById('HeaderTableStep3').style.backgroundColor = '#2bcf51';
    document.getElementById('HeaderTableStep4').style.backgroundColor = '#2bc9cf';
    document.getElementById('HeaderTableStep1').style.backgroundColor = '#2bcf51';
    document.getElementById('Step3').style.display = 'none';
    document.getElementById('Step4').style.display = 'inline';
    document.getElementById("previous").style.display = "inline";
    document.getElementById("submit").style.display = "none";
    document.getElementById('previous').name = 'Step3';
    loadStep5Review();
}