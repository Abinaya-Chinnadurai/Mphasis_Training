package com.java.pack2;

public class ProtectedModifier {
		protected void ProtectedClass() {
			System.out.println("\nI am Protected Access Modifier Outside Class");
		}
		
	
}
