package com.java.pack2;

public class PublicModifier {
	public void PublicClass() {
		System.out.println("\nI am Public Access Modifier within package");
	}
}
