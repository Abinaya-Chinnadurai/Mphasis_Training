package com.java.pack2;
import com.*;
import com.java.*;
import com.java.pack1.ASTest;
class DefaultModifier{
	public void DefaultClass() {
		System.out.println("\nI am Default Access Modifier within Package!!");
	}
}

public class AccessSpecifiersTest {
	private void PrivateModifier() {
 	   System.out.println("\nI am Private Access Modifier within Class!!");
    }
	public static void main(String[] args) {
		AccessSpecifiersTest test = new AccessSpecifiersTest(); 
		DefaultModifier dm = new DefaultModifier();
		ProtectedModifier pm = new ProtectedModifier();
		PublicModifier pb = new PublicModifier();
		ASTest ast = new ASTest();
		test.PrivateModifier();
		dm.DefaultClass();
		pm.ProtectedClass();
		pb.PublicClass();
		ast.PublicDisplay();
		
	}

}
