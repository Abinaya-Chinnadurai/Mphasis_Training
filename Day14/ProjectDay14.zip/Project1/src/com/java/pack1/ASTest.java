package com.java.pack1;
public class ASTest {
       public void PublicDisplay() {
    	   System.out.println("\nI am Public Access Modifier outside Package :)");
       }
}
