package com.java.pack1;

import java.util.Comparator;

public class NameComparator implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
			Product p1 = (Product)o1;
			Product p2 = (Product)o2;
			if(o1.getProname().equals(o2.getProname())){
				
    			if (p1.getPrice() >= p2.getPrice()) {
	      			return 1;
			     } else {
			     	  return -1;
           			}
			
		}else {
		return o1.getProname().compareTo(o2.getProname()); 
		}
	}

}
