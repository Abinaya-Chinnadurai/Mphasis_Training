package com.java.pack1;

public class Product {

		private int proid;  
	    private String proname;  
        private double price;
		
        public Product() {}

		public Product(int proid, String proname, double price) {
			this.proid = proid;
			this.proname = proname;
			this.price = price;
		}
		
		

		public int getProid() {
			return proid;
		}

		public void setProid(int proid) {
			this.proid = proid;
		}

		public String getProname() {
			return proname;
		}

		public void setProname(String proname) {
			this.proname = proname;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		@Override
		public String toString() {
			return "Product_ID= " + proid + "     Product_Name= " + proname + "      Product_Price= " + price ;
		}
		
}
