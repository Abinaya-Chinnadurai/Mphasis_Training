package com.java.pack1;

import java.util.*;

public class ProductShow {

	public static void main(String[] args) {
           Comparator<Product> comp = new NameComparator();
           SortedSet<Product> productList = new TreeSet<Product>(comp);
           productList.add(new Product(1,"Notebook",25202.52));
           productList.add(new Product(2,"Pen",10000));
           productList.add(new Product(3,"Pen",78936.61));
           productList.add(new Product(4,"Sharpener",2379.61));
           productList.add(new Product(5,"Eraser",43205));
           productList.add(new Product(6,"Sharpener",68079.48));
           productList.add(new Product(7,"Eraser",5445.52));
           productList.add(new Product(8,"Sketch",3052));
           
           System.out.println("Sorted List using Name and Price Displaying through foreach method:");
           System.out.println("--------------------------------------------");
           for (Product product : productList) {
        	   System.out.println(product);			
		   }
           
           System.out.println("\nDisplaying through Lambda Expression method:");
           System.out.println("---------------------------=----------------");
           productList.forEach((i)->System.out.println(i));
                     
           System.out.println("\nDisplaying Products Which has price more than 30000:");
           System.out.println("---------------------------------------------------");           
           for (Product product : productList) {
        	   if(product.getPrice()>30000) {
        		   System.out.println(product);
        	   }
			
		}
           
	}

}
