package com.java.file;

import java.io.*;

public class FileISDataRead {

	public static void main(String[] args) {
 
		try {
			FileInputStream src = new FileInputStream("D:/Files/FileData.txt");
			DataInputStream input = new DataInputStream(src);
		    int i = input.readInt();
		    boolean bool = input.readBoolean();
		    double d = input.readDouble();
			String str = input.readUTF();
			System.out.println(bool);
			System.out.println(i);
			System.out.println(str);
			System.out.println(d);
			input.close();
			src.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
         
	}

}
