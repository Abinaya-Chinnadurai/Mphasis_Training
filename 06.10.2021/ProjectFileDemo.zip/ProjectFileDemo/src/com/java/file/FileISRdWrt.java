package com.java.file;

import java.io.*;

public class FileISRdWrt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileInputStream src = new FileInputStream("D:/Mphasis/05.10.2021/ProjectFileDemo/src/com/java/file/FileIS.java");
			FileOutputStream target = new FileOutputStream("D:/Files/FileIS.txt");
			int ch;
			while((ch = src.read())!= -1) {
				target.write(ch);
			}
			src.close();
			target.close();
			System.out.println("Wrote!!");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
