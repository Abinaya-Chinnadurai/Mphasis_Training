package com.java.file;

import java.io.*;

public class FileISDataWrite {

	public static void main(String[] args) {
    try {
		FileOutputStream target = new FileOutputStream("D:/Files/FileData.txt");
	    DataOutputStream output = new DataOutputStream(target);
	    output.writeInt(50);
	    output.writeBoolean(true);
	    output.writeDouble(789.321);
	    output.writeUTF("Hello Abinaya");
	    output.close();
	    target.close();
    }
    
    catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
