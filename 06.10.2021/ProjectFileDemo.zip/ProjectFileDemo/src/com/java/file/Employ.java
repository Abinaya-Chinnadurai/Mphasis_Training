package com.java.file;

public class Employ {
     
	private int empid;
	private String empname;
	private double basic;
	public Employ() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employ(int empid, String empname, double basic) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.basic = basic;
	}
	
}
