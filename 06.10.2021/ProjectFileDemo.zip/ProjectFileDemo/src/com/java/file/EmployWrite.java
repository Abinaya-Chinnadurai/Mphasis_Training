package com.java.file;

import java.io.*;

public class EmployWrite {

	public static void main(String[] args) {
		try {
			FileOutputStream fout = new FileOutputStream("D:/Files/Employ.txt");
			ObjectOutputStream objout = new ObjectOutputStream(fout);
			Employ employ = new Employ(1, "Anshual", 92344);
			objout.writeObject(employ);
			objout.close();
			fout.close();
			System.out.println("*** Employ Records Stored ***");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
