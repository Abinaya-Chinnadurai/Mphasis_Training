package com.java.file;

import java.io.*;
import java.util.*;

public class ObjectOutS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			FileOutputStream target = new FileOutputStream("D:/Files/Date.txt");
			ObjectOutputStream obj = new ObjectOutputStream(target);
			obj.writeObject(new Date());
			obj.close();
			target.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
