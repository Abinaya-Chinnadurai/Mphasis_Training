package com.java.file;

import java.io.*;

public class ObjectInS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileInputStream src = new FileInputStream("D:/Files/Date.txt");
			ObjectInputStream in = new ObjectInputStream(src);
			Object date = in.readObject();
			System.out.println(date);
			in.close();
			src.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
