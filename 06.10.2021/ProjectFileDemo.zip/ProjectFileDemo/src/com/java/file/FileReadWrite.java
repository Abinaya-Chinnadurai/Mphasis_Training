package com.java.file;

import java.io.*;

public class FileReadWrite {

	public static void main(String[] args) {
       File src = new File("D:/Mphasis/05.10.2021/ProjectFileDemo/src/com/java/file/FileDirectoryRead.java");
	   File target = new File("D:/Files/FileDirectoryRead.txt");
	   try {
		FileReader rd = new FileReader(src);
		FileWriter wrt = new FileWriter(target);
		int ch;
		while((ch = rd.read()) != -1) {
			wrt.write((char)ch);
		}
		rd.close();
		wrt.close();
		System.out.println("wrote");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
