package com.java.file;

import java.io.*;

public class EmployRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileInputStream src = new FileInputStream("D:/Files/Employ.txt");
			ObjectInputStream obj = new ObjectInputStream(src);
			Employ employ = (Employ)obj.readObject();
			System.out.println(employ);
			obj.close();
			src.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
