package com.java.agent;

public enum Gender {
        MALE,FEMALE,OTHERS
}
