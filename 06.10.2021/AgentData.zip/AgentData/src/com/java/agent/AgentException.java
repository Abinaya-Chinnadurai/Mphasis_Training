package com.java.agent;

public class AgentException extends Exception {

	public AgentException() {
	}

		AgentException (String error){
			super(error);
		}

}
