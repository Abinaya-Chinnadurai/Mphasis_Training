package com.java.agent;

import java.util.*;
public class AgentDAO {
	
	static List<Agent> agentList = new ArrayList<Agent>();

	public static String addAgentDAO(Agent agent) {
		agentList.add(agent);
		return "Added Successfully :)\n";		
	}

	public List<Agent> showAgentDAO() {
		return agentList;
	}

	public static Agent searchAgentDAO(int id) {
		Agent agent = null;
		for (Agent a : agentList) {
			if(a.getAgentId()== id) {
				agent = a;
			}
		}
		return agent;
	}

	public static String deleteAgentDAO(int id) {
          Agent agent = searchAgentDAO(id);
          if(agent == null) {
        	  return "No Matching Records Found :(";
          }else {
        	  agentList.remove(agent);
        	  return "Deleted Successfully :)";
          }
	}

	public String updateAgentDAO(Agent agentnew) {
         Agent old = searchAgentDAO(agentnew.getAgentId());
         if(old != null) {
        	 old.setAgentId(agentnew.getAgentId());
        	 old.setName(agentnew.getName());
        	 old.setCity(agentnew.getCity());
        	 old.setGender(agentnew.getGender());
        	 old.setPremium(agentnew.getPremium());
        	 return "Updated Successfully :)";
         }
         else {
        	 return "Record not found";
         }
	}
}











