package com.java.agent;

import java.util.*;

public class AgentMain {
     static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		int choice;
		do {
			System.out.println("OPERATIONS CAN BE PERFORMED:\n----------------------------");
			System.out.println("1.Add Agent\n2.Show Agent\n3.Search Agent\n4.Delete Agent\n5.Update Agent\n6.Exit");
			System.out.println("Enter your choice:");
			choice = scan.nextInt();
		        
		switch(choice) {
		case 1:
			
			try {
				addAgent();
			} catch (AgentException e) {
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			showAgent();
			break;
		case 3:
			searchAgent();
			break;
		case 4:
			deleteAgent();
			break;
		case 5:
			try {
				updateAgent();
			} catch (AgentException e) {
                    System.out.println(e.getMessage());
			}
			break;
		case 6:
			System.exit(1);
			break;
		default:
			System.out.println("Choose Correct Choice!\n");
		}
		}while(choice<7);
	}
	public static void updateAgent() throws AgentException {
		   System.out.println("Enter Agent ID :");	
		   Agent agent = new Agent();
		   agent.setAgentId(scan.nextInt());
		   System.out.println("Enter Agent Name:");
		   agent.setName(scan.next());
		   System.out.println("Enter City:");
		   agent.setCity(scan.next());
		   System.out.println("Enter Gender:");
		   String str=scan.next();
		   String gen = str.toUpperCase();
		   agent.setGender(Gender.valueOf(gen));
		   System.out.println("Enter premium:");
		   agent.setPremium(scan.nextDouble());  
		  
		  System.out.println(new AgentBAL().updateAgentBAL(agent));
	}
	public static void deleteAgent() {
            System.out.println("Enter Agent ID to delete:");	
            int id = scan.nextInt();
            System.out.println(new AgentBAL().deleteAgentBAL(id));
	}
	public static void searchAgent() {
           System.out.println("Enter Agent ID to search:");
           int id = scan.nextInt();
           Agent record = new AgentBAL().searchAgentBAL(id);
           if(record == null) {
        	   System.out.println("No such Agent :(");
           }
           else {
        	   System.out.println(record);
           }
		
	}
	public static void showAgent() {
		System.out.println("AgentID \t Agent Name\t\tCity\t\tGender\t\tPremium");
	    System.out.println(new AgentDAO().showAgentDAO());
	}
	public static void addAgent() throws AgentException{
		Agent agent = new Agent();
	   System.out.println("Enter Agent Id:");
	   agent.setAgentId(scan.nextInt());
	   System.out.println("Enter Agent Name:");
	   agent.setName(scan.next());
	   System.out.println("Enter City:");
	   agent.setCity(scan.next());
	   System.out.println("Enter Gender:");
	   String str=scan.next();
	   String gen = str.toUpperCase();
	   agent.setGender(Gender.valueOf(gen));
	   System.out.println("Enter premium:");
	   agent.setPremium(scan.nextDouble());
	   
	    AgentBAL bal = new AgentBAL();
	    System.out.println(bal.addAgentBAL(agent));
          		
	}
	

}


