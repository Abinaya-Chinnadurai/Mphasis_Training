package com.java.agent;

import java.util.*;
public class AgentBAL {
    StringBuilder sb = new StringBuilder();
    AgentDAO dao = new AgentDAO(); 
    
	public String addAgentBAL(Agent agent) throws AgentException  {
		if(ValidateAgent(agent)== true) {
			return dao.addAgentDAO(agent);
		}else {
			throw new AgentException(sb.toString());
		}
		
	}
	private boolean ValidateAgent(Agent agent) {
		boolean isAdded = true;
		if(agent.getAgentId()<=0) {
			isAdded = false;
			sb.append("Agent ID must not be Zero or Negative\n");
		}
		if(agent.getName().length()<=3) {
			isAdded = false;
			sb.append("Name must be more than 3 characters\n");
		}
		if(agent.getCity().length()<=3) {
			isAdded = false;
			sb.append("City must be more than 3 characters\n");
		}
		if(agent.getPremium()<1000) {
			isAdded = false;
			sb.append("Premium must be greater than 1000\n");
		}
		return isAdded;
	}
	
	public List<Agent> showAgentBAL() {
		return dao.showAgentDAO();
	}
	
	public Agent searchAgentBAL(int id) {
		return dao.searchAgentDAO(id);
	}
	
	public String deleteAgentBAL(int id) {
		return dao.deleteAgentDAO(id);
	}
	
	public String updateAgentBAL(Agent agent) throws AgentException  {
		if(ValidateAgent(agent) == true)
		{
			return dao.updateAgentDAO(agent);
		}
		
		else {
			throw new AgentException(sb.toString());
		}

	}

}









