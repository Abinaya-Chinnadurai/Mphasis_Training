package com.java.leave;

import java.util.*;
import java.text.*;

public class leaveDAO {
	
	static List<LeaveDetails> leavelist = new ArrayList<LeaveDetails>();

	public static void addLeavedao(LeaveDetails leaveDetails) {
		leavelist.add(leaveDetails);		
	}

	public int noOfDaysDao() {
        Date st = new LeaveDetails().getLeaveStartDate();
        Date ed = new LeaveDetails().getLeaveEndDate();
        long diff = ed.getTime() - st.getTime();
        long newdiff = diff / 1000 / 60 / 60 / 24;
        int nod = (int)newdiff;
		return  nod+1;
	}

	public void showLeavesDAO() {
		for (LeaveDetails leaveDetails : leavelist) {
			System.out.println(leaveDetails);
		}
	}

	public LeaveDetails searchLeaveDAO(int id) {
           LeaveDetails leavedetails = null;
           for (LeaveDetails leaveDetails : leavelist) {
        	   if(leaveDetails.getLeaveId() == id )
        		   {leavedetails = leaveDetails;	}
        	   else {System.out.println("not found");}
		}
           return leavedetails;
	}

	public void updateLeaveDAO(LeaveDetails newld) {
                LeaveDetails old = searchLeaveDAO(newld.getLeaveId());
                if(old!=null) {
                	old.setLeaveId(newld.getLeaveId());
                	old.setEmpId(newld.getEmpId());
                	old.setLeaveStartDate(newld.getLeaveStartDate());
                	old.setLeaveEndDate(newld.getLeaveEndDate());
                	old.setLeaveReason(newld.getLeaveReason());
                	old.setNoOfDays(newld.getNoOfDays());
                }
	}

	public String deleteLeaveDAO(int id) {
           LeaveDetails leave = searchLeaveDAO(id);
           if(leave != null) {
        	   leavelist.remove(leave);
        	   return "deleted !!";
           }
           else {
        	   return "Not Found";
           }
	}
	
	

}
